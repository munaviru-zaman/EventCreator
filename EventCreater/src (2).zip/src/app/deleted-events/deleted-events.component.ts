import { HttpClient } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deleted-events',
  templateUrl: './deleted-events.component.html',
  styleUrls: ['./deleted-events.component.css'],
})
export class DeletedEventsComponent implements OnInit {
  deletedArray: any;
  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    var userId = JSON.parse(localStorage.getItem('user_id') || '');
    this.http
      .get('http://localhost:3000/deletedEvents/' + userId)
      .subscribe((result: any) => {
        if (result) {
          this.deletedArray = result;
        }
      });
  }
  deleteEvent() {
    this.router.navigateByUrl('eventAdder');
  }
}
