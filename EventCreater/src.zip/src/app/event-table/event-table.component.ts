import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-event-table',
  templateUrl: './event-table.component.html',
  styleUrls: ['./event-table.component.css'],
})
export class EventTableComponent implements OnInit {
  currentUser: any;
  constructor(private router: Router) {}

  ngOnInit(): void {}
  deleteDiv() {
    this.currentUser = 8;
  }
  cancelDiv() {
    this.currentUser = '';
  }
  eventdelete() {
    this.router.navigateByUrl('deletedevents');
  }
}
