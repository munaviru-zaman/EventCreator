import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-deleted-events',
  templateUrl: './deleted-events.component.html',
  styleUrls: ['./deleted-events.component.css'],
})
export class DeletedEventsComponent implements OnInit {
  constructor(private router: Router) {}

  ngOnInit(): void {}
}
