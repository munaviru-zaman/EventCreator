import { HttpClient } from '@angular/common/http';
import { Component, Input, OnInit } from '@angular/core';
import { Route, Router } from '@angular/router';

@Component({
  selector: 'app-event-adder',
  templateUrl: './event-adder.component.html',
  styleUrls: ['./event-adder.component.css'],
})
export class EventAdderComponent implements OnInit {
  user_id: any;
  e_name: any;
  e_date: any;
  priority: any;
  currentUser: any;

  constructor(private router: Router, private http: HttpClient) {}

  ngOnInit(): void {
    this.user_id = JSON.parse(localStorage.getItem('user_id') || '');
  }
  addEvent() {
    this.currentUser = this.user_id;
  }
  eventcancel() {
    this.currentUser = '';
  }
  eventcreate() {
    var event_name = this.e_name;
    var event_date = this.e_date;
    var userId = this.user_id;
    var priority = this.priority;

    const newEvent = {
      event_name,
      event_date,
      userId,
      priority,
    };

    return this.http
      .post('http://localhost:3000/eventcreate', newEvent)
      .subscribe(
        (result: any) => {
          if (result) {
            alert(result.message);
            this.router.navigateByUrl('events');
          }
        },
        (result) => {
          alert(result.error.message);
        }
      );
  }
}
